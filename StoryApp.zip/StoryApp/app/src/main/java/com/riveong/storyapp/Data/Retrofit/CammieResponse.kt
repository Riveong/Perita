package com.riveong.storyapp.Data.Retrofit

import com.google.gson.annotations.SerializedName

data class CammieResponse(
    @field:SerializedName("error")
    val error: Boolean,
    @field:SerializedName("message")
    val message: String
)